Terms Of Use!
By installing or using this font, you have read and accepted our Terms and Use Agreement :

1. This font is only for NON COMMERCIAL or PERSONAL USE ONLY.

2. Here is the link to purchase COMMERCIAL LICENSE :

https://hanscostudio.com/product/ballomont/

contact us : burhanafif@gmail.com

Any donation are very appreciated,
Paypal account for donation : https://www.paypal.me/burhanafif

Thank you.
Burhan Afif
HansCo Owner